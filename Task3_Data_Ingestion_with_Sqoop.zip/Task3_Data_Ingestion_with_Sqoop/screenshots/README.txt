Place your own genuine screenshots here after running the project, such as MySQL table output, successful Sqoop import, and HDFS file contents. Do not use placeholder images as proof of execution.
